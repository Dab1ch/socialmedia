from django.urls import path
from . import views


urlpatterns = [
    path('accounts', views.index, name = 'accounts'),
    path('accounts/id<int:pk>', views.user, name = 'user'),
    path('', views.about, name = 'about'),
    path('register', views.register, name = 'register'),
    path('login', views.login, name='login'),
    path('upload', views.upload, name = 'upload')
]