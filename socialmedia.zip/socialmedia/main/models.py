from django.db import models

# Create your models here.
class Users(models.Model):
    username = models.CharField('Имя пользователя', max_length=30)
    email = models.EmailField('Электронная почта')
    password = models.CharField('Пароль', max_length=30)
    numpics = models.IntegerField('Количество фотографий', default=0)

    def __str__(self):
        return self.username

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'