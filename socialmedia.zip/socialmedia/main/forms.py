from .models import Users
from django.forms import ModelForm, TextInput, PasswordInput, EmailInput

class UsersForm(ModelForm):
    class Meta:
        model = Users
        fields = ['username', 'email', 'password']

        widgets = {
            'username': TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Имя пользователя'
            }),
            'email': EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Электронная почта'
            }),
            'password': PasswordInput(attrs={
                'class': 'form-control',
                'placeholder': 'Пароль'
            })
        }