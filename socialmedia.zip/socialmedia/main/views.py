from django.shortcuts import render, redirect
from .models import Users
from .forms import UsersForm
from django.views.generic import DetailView
from PIL import Image
import os
import cv2

# Create your views here.
def index(request):
    data = {
        'fl':request.session['fl'],
        'my_id' : request.session['id'],
        'check' : True,
        'data': Users.objects.order_by('id')
    }
    return render(request, 'main/index.html', data)

def about(request):
    data = {
        'fl':request.session['fl'],
        'my_id' : request.session['id'],
        'check' : True
    }
    return render(request, 'main/about.html', data)

def register(request):
    request.session['id'] = -1
    error = ''
    request.session['fl'] = False
    request.session['login'] = True
    if request.method == 'POST':
        form = UsersForm(request.POST)
        fl = True
        for i in Users.objects.all():
            if i.username == request.POST['username']:
                error = 'Такое имя пользователя уже занято'
                fl = False
                break

        if form.is_valid():
            print(Users.objects.all())
            if fl:
                form.save()
                request.session['fl'] = True
                request.session['username'] = request.POST['username']
                request.session['login'] = False
                request.session['id'] = Users.objects.all()[len(Users.objects.all()) - 1].id
                request.session['cur_user'] = len(Users.objects.all()) - 1
                return redirect('about')
            fl = True

    form = UsersForm()
    request.session['fl'] = False
    data = {
        'form':form,
        'error':error,
        'fl' : request.session['fl'],
        'login': request.session['login'],
        'check' : True
    }
    return render(request, 'main/register.html', data)

def login(request):
    request.session['id'] = -1
    request.session['login'] = True
    error = ''
    request.session['fl'] = False
    if request.method == 'POST':
        form = UsersForm(request.POST)
        print('aaaaaaaaaaaa')
        k = 0
        for i in Users.objects.all():
            print('bbbbbbbbbbbbbbbbbb')
            print(i.username)
            k+=1
            if i.username == request.POST['username'] and i.password == request.POST['password']:
                print('ccc')
                request.session['username'] = request.POST['username']
                request.session['fl'] = True
                request.session['login'] = False
                request.session['id'] = i.id
                request.session['cur_user'] = k
                #request.session['cur_user'] = i
                return redirect('about')

        
        error = 'Ошибка в имени пользователя или пароле, попробуйте ещё раз'


    form = UsersForm()
    request.session['fl'] = False
    data = {
        'form':form,
        'error':error,
        'fl' : request.session['fl'],
        'login': request.session['login'],
        'check' : True
    }
    return render(request, 'main/login.html', data)

class UsersPages(DetailView):
    model = Users
    template_name = 'main/user.html'
    context_object_name = 'user'

def user(request, pk):
    request.session['login'] = False
    for i in Users.objects.all():
        if i.id == pk:
            cur_user = i
            break
    check = True
    if pk == request.session['id']:
        check = False
    pic_list = []
    for i in range(cur_user.numpics):
        pic_list.append('pics/main/' + str(pk) + '/pic' + str(i) + '.jpg')

    num_divs = []
    if cur_user.numpics % 5 != 0:
        for i in range(10 - (cur_user.numpics)%5):
            num_divs.append(0)

    
    data= {
        'my_id':request.session['id'],
        'num_divs' : num_divs,
        'id':pk,
        'pic_list':pic_list,
        'user':cur_user,
        'fl' : request.session['fl'],
        'login': request.session['login'],
        'check' : check,
    }
    return render(request, 'main/user.html', data)

def upload(request):
    if request.method == 'POST':
        picture = request.POST.get('upload')
        isWritten = cv2.imwrite('C:/users/ilyak/desktop/соцсеть/socialmedia/main/static/pics/main/pic'+str(Users.objects.all()[request.session['cur_user']].numpics)+'.jpg', picture) 
        if isWritten: 
            print('Image is successfully saved as file.')
        return redirect('user', Users.objects.all()[request.session['cur_user']].id)
    return render(request, 'main/upload.html')